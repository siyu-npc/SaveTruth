/*! TenVideoPlayer_V2 - v2.0.0 - 2016-08-26 20:58:18
 * Copyright (c) 2016
 * Powered by Tencent-Video Web Front End Team 
*/
window.tvp||(tvp={}),tvp.config={defaultConfig:{caseSetting:{case3:{}},app3gConfirm:1e3},authRules:[{reg:function(){return location.hostname.indexOf("caixin.com")>-1?!0:!1},request:function(a){var b=this,c={cgi:b.cfg2.cgi.getinfo,param:{platform:"961001",sdtfrom:"v1093",vids:b.cfg.vid,defaultfmt:b.cfg.fmt}};a.resolve(c)}}]};